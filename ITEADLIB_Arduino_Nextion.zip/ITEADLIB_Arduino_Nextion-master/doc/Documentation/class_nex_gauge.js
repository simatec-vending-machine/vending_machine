var class_nex_gauge =
[
    [ "NexGauge", "class_nex_gauge.html#ac79040067d42f7f1ba16cc4a1dfd8b9b", null ],
    [ "getValue", "class_nex_gauge.html#aeea8933513ebba11584ad97f8c8b5e69", null ],
    [ "setValue", "class_nex_gauge.html#a448ce9ad69f54c156c325d578a96b765", null ]
];