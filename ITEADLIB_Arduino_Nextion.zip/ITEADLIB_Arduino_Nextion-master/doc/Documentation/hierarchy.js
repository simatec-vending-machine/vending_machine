var hierarchy =
[
    [ "NexObject", "class_nex_object.html", [
      [ "NexGauge", "class_nex_gauge.html", null ],
      [ "NexProgressBar", "class_nex_progress_bar.html", null ],
      [ "NexTouch", "class_nex_touch.html", [
        [ "NexButton", "class_nex_button.html", null ],
        [ "NexCrop", "class_nex_crop.html", null ],
        [ "NexDSButton", "class_nex_d_s_button.html", null ],
        [ "NexHotspot", "class_nex_hotspot.html", null ],
        [ "NexNumber", "class_nex_number.html", null ],
        [ "NexPage", "class_nex_page.html", null ],
        [ "NexPicture", "class_nex_picture.html", null ],
        [ "NexSlider", "class_nex_slider.html", null ],
        [ "NexText", "class_nex_text.html", null ],
        [ "NexTimer", "class_nex_timer.html", null ]
      ] ],
      [ "NexWaveform", "class_nex_waveform.html", null ]
    ] ]
];